package com.DTO.TiendaVirtualSB;

public class ClienteVO {
	
	 private Integer idCliente;
	 private String nombreCliente;
	 private String apellidoCliente;
	 
	 /**
	  * @return the idCliente
	  */
	 public Integer getIdCliente() {
	  return idCliente;
	 }
	 
	 /**
	  * @param idCliente the idCliente to set
	  */
	 public void setIdCliente(Integer idCliente) {
	  this.idCliente = idCliente;
	 }
	 
	 
	 /**
	  * @return the nombreCliente
	  */
	 public String getNombreCliente() {
	  return nombreCliente;
	 }
	 /**
	  * @param nombreCliente the nombreCliente to set
	  */
	 public void setNombreCliente(String nombreCliente) {
	  this.nombreCliente = nombreCliente;
	 }
	 
	 
	 /**
	  * @return the nombreCliente
	  */
	 public String getApellidoCliente() {
	  return apellidoCliente;
	 }
	 /**
	  * @param nombreCliente the nombreCliente to set
	  */
	 public void setApellidoCliente(String nombreCliente) {
	  this.apellidoCliente = nombreCliente;
	 }
	 

}
